
import React, { useState, useEffect, useMemo } from 'react';
import { Meeting, RoomInfo, RoomStatus } from '../types';
import { fetchRoomMeetings, getRoomDisplayName } from '../services/microsoftGraph';
import { getSmartAgendaSummary } from '../services/geminiService';
import Logo from './Logo';

interface RoomDisplayProps {
  room: RoomInfo;
  onReset: () => void;
}

const RoomDisplay: React.FC<RoomDisplayProps> = ({ room, onReset }) => {
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [displayName, setDisplayName] = useState<string>(room.name);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [smartSummary, setSmartSummary] = useState('');
  const [errorStatus, setErrorStatus] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    
    const loadData = async () => {
      try {
        const realName = await getRoomDisplayName(room.email);
        if (realName) {
          setDisplayName(realName);
        }

        const data = await fetchRoomMeetings(room.email);
        setMeetings(data);
        
        const summary = await getSmartAgendaSummary(data, realName || room.name);
        setSmartSummary(summary);
        
        setErrorStatus(null);
      } catch (err: any) {
        console.error("Erro na sincronização:", err);
        setErrorStatus(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadData();
    const sync = setInterval(loadData, 60000); // Sincronização a cada 1 minuto
    
    return () => { 
      clearInterval(timer); 
      clearInterval(sync); 
    };
  }, [room]);

  const currentMeeting = useMemo(() => {
    return meetings.find(m => currentTime >= m.startTime && currentTime <= m.endTime);
  }, [meetings, currentTime]);

  const status = currentMeeting ? RoomStatus.OCCUPIED : RoomStatus.AVAILABLE;
  const bgColor = status === RoomStatus.OCCUPIED ? 'bg-[#C5202D]' : 'bg-[#059669]';

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  const calculateProgress = (start: Date, end: Date) => {
    const total = end.getTime() - start.getTime();
    const elapsed = currentTime.getTime() - start.getTime();
    return Math.min(Math.max((elapsed / total) * 100, 0), 100);
  };

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-zinc-950">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
          <Logo className="text-4xl opacity-20" variant="white" />
          <p className="text-white/40 text-sm font-bold tracking-[0.3em] uppercase mt-4">Conectando ao Exchange...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`h-screen w-screen flex flex-col transition-colors duration-1000 ${bgColor}`}>
      {/* HEADER */}
      <header className="p-8 pt-10 flex justify-between items-start bg-gradient-to-b from-black/30 to-transparent">
        <div className="flex flex-col gap-4">
          <Logo className="text-3xl" variant="white" />
          <h1 className="text-5xl font-black text-white uppercase tracking-tighter drop-shadow-xl leading-none mt-2 max-w-xl">
            {displayName}
          </h1>
        </div>
        <div className="text-right">
          <div className="text-8xl font-black text-white tracking-tighter leading-none">
            {currentTime.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
          </div>
          <div className="text-lg font-bold uppercase text-white/80 tracking-widest mt-1">
            {currentTime.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'short' })}
          </div>
        </div>
      </header>

      {/* STATUS AREA */}
      <main className="flex-1 flex flex-col justify-center px-10">
        <div className="space-y-2 mb-4">
          <span className="text-white/60 font-black uppercase tracking-[0.4em] text-sm flex items-center gap-2">
            <span className={`w-2 h-2 bg-white rounded-full ${status === RoomStatus.OCCUPIED ? 'animate-pulse' : ''}`}></span>
            {status === RoomStatus.OCCUPIED ? 'Sala em uso' : 'Sala disponível'}
          </span>
          <h2 className="text-[10rem] font-black text-white leading-none tracking-tighter drop-shadow-2xl">
            {status === RoomStatus.OCCUPIED ? 'OCUPADA' : 'LIVRE'}
          </h2>
        </div>

        {currentMeeting ? (
          <div className="p-10 bg-black/40 rounded-[3rem] backdrop-blur-3xl border border-white/20 shadow-2xl relative overflow-hidden">
            {/* PROGRESS BAR BACKGROUND */}
            <div className="absolute bottom-0 left-0 h-2 bg-white/10 w-full">
               <div 
                 className="h-full bg-white transition-all duration-1000" 
                 style={{ width: `${calculateProgress(currentMeeting.startTime, currentMeeting.endTime)}%` }}
               />
            </div>

            <div className="flex flex-col gap-1">
              <p className="text-white/40 uppercase text-xs font-black tracking-[0.4em] mb-2">Organizador da Reunião</p>
              <h3 className="text-5xl font-black text-white leading-tight tracking-tight uppercase truncate">
                {currentMeeting.organizer}
              </h3>
            </div>
            
            <div className="flex items-center gap-8 mt-8 pt-8 border-t border-white/10">
              <div className="flex flex-col">
                <span className="text-white/40 text-xs uppercase font-black tracking-widest mb-1">Início</span>
                <span className="text-4xl font-black text-white">{formatTime(currentMeeting.startTime)}</span>
              </div>
              
              <div className="w-10 h-1 bg-white/20 rounded-full mt-6"></div>

              <div className="flex flex-col">
                <span className="text-white/40 text-xs uppercase font-black tracking-widest mb-1">Fim</span>
                <span className="text-4xl font-black text-white">{formatTime(currentMeeting.endTime)}</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white/10 p-10 rounded-[2.5rem] border border-white/10 max-w-3xl">
            <p className="text-3xl text-white font-medium leading-tight italic tracking-tight">
              {errorStatus ? "Aguardando sincronização de agenda..." : smartSummary}
            </p>
          </div>
        )}
      </main>

      {/* AGENDA SECTION */}
      <footer className="bg-zinc-950 p-10 pt-12 rounded-t-[4.5rem] h-[38vh] shadow-[0_-30px_60px_-15px_rgba(0,0,0,0.8)] flex flex-col relative">
        <div className="flex justify-between items-center mb-6 px-2">
          <h3 className="text-3xl font-black text-zinc-100 uppercase tracking-tighter flex items-center gap-4">
            <span className="w-3 h-3 bg-white rounded-full"></span>
            Agenda de Hoje
          </h3>
          <p className="text-zinc-600 font-bold uppercase tracking-widest text-[10px]">Sincronizado</p>
        </div>

        <div className="flex-1 overflow-y-auto space-y-4 pr-2">
          {meetings.length === 0 ? (
            <div className="h-full flex justify-center items-center text-zinc-800 text-xl font-black italic uppercase tracking-[0.2em]">
              Sem agenda para hoje
            </div>
          ) : (
            meetings.map((m) => {
              const isActive = currentTime >= m.startTime && currentTime <= m.endTime;
              const isPast = currentTime > m.endTime;
              
              if (isPast && !isActive) return null;

              return (
                <div 
                  key={m.id} 
                  className={`p-6 rounded-[2rem] flex items-center gap-6 transition-all border ${isActive ? 'bg-white/5 border-white/40 scale-[1.02] shadow-xl shadow-white/5' : 'bg-zinc-900/40 border-zinc-800/50'}`}
                >
                  <div className={`text-center w-36 border-r pr-6 ${isActive ? 'border-white/20' : 'border-zinc-800'}`}>
                    <span className={`text-2xl font-black block ${isActive ? 'text-white' : 'text-zinc-300'}`}>
                      {formatTime(m.startTime)}
                    </span>
                    <span className="text-[10px] text-zinc-600 uppercase font-black tracking-widest">Início</span>
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <h4 className={`text-2xl font-bold truncate ${isActive ? 'text-white' : 'text-zinc-400'}`}>
                      {m.organizer}
                    </h4>
                    <p className="text-zinc-600 text-sm font-bold uppercase tracking-wider truncate">
                      {formatTime(m.startTime)} — {formatTime(m.endTime)}
                    </p>
                  </div>
                  {isActive && (
                    <div className="bg-white/10 px-4 py-2 rounded-full text-[10px] font-black text-white uppercase tracking-widest animate-pulse">
                      Agora
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        <div 
          onDoubleClick={onReset}
          className="absolute top-4 right-1/2 translate-x-1/2 w-32 h-2 bg-zinc-900 rounded-full opacity-30 cursor-pointer"
          title="Duplo clique para redefinir"
        ></div>
      </footer>
    </div>
  );
};

export default RoomDisplay;
