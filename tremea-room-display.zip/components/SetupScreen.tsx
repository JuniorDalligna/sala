
import React from 'react';
import { RoomInfo, ROOMS } from '../types';
import Logo from './Logo';

interface SetupScreenProps {
  onComplete: (room: RoomInfo) => void;
}

const SetupScreen: React.FC<SetupScreenProps> = ({ onComplete }) => {
  return (
    <div className="h-screen w-screen bg-zinc-950 flex flex-col p-12 items-center justify-center">
      <div className="flex flex-col items-center mb-16">
        <Logo className="text-6xl" variant="white" />
        <div className="h-1 w-24 bg-[#C5202D] rounded-full mt-6"></div>
      </div>
      
      <div className="w-full max-w-md space-y-6">
        <h2 className="text-zinc-400 text-sm uppercase font-black tracking-widest text-center border-b border-zinc-900 pb-4">
          Configuração do Tablet
        </h2>
        
        <p className="text-white text-center text-lg mb-4">Em qual sala este tablet será fixado?</p>

        <div className="grid gap-4">
          {ROOMS.map(room => (
            <button
              key={room.id}
              onClick={() => onComplete(room)}
              className="w-full bg-zinc-900 border border-zinc-800 p-8 rounded-3xl text-left hover:bg-zinc-800 hover:border-[#C5202D]/50 transition-all group flex justify-between items-center"
            >
              <div>
                <h3 className="text-2xl font-black text-white group-hover:text-white transition-colors uppercase tracking-tighter">
                  {room.name}
                </h3>
                <p className="text-zinc-500 text-sm italic">{room.email}</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-500 group-hover:bg-[#C5202D] group-hover:text-white transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </button>
          ))}
        </div>
      </div>

      <p className="mt-16 text-zinc-600 text-[10px] uppercase font-bold tracking-widest">
        Sistema de Gestão TREMÉA v4.0
      </p>
    </div>
  );
};

export default SetupScreen;
