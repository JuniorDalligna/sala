
import React from 'react';

interface LogoProps {
  className?: string;
  variant?: 'light' | 'dark' | 'white';
}

const Logo: React.FC<LogoProps> = ({ className = "", variant = 'white' }) => {
  const textColor = variant === 'white' ? 'text-white' : (variant === 'dark' ? 'text-zinc-900' : 'text-[#C5202D]');
  
  return (
    <div className={`font-black tracking-tighter ${textColor} ${className}`} style={{ fontSize: '1.2em' }}>
      TREMÉA
    </div>
  );
};

export default Logo;
