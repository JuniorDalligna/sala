
import * as msal from "@azure/msal-browser";
import { Client } from "@microsoft/microsoft-graph-client";
import { Meeting } from '../types';

const CLIENT_ID = "962b89b0-ee95-4aba-a8cb-2c6b30e192b7";
const TENANT_ID = "d7e6af06-a5ea-4970-a58e-d9f9d70d284a";

const REDIRECT_URI = window.location.origin.replace(/\/$/, "");

let msalInstance: msal.PublicClientApplication | null = null;

export const initMsal = async () => {
  const msalConfig: msal.Configuration = {
    auth: {
      clientId: CLIENT_ID,
      authority: `https://login.microsoftonline.com/${TENANT_ID}`,
      redirectUri: REDIRECT_URI,
    },
    cache: {
      cacheLocation: "localStorage",
      storeAuthStateInCookie: true,
    },
    system: {
      allowRedirectInIframe: true,
      navigateFrameWait: 0
    }
  };
  
  msalInstance = new msal.PublicClientApplication(msalConfig);
  await msalInstance.initialize();
  
  try {
    const response = await msalInstance.handleRedirectPromise();
    if (response) {
      msalInstance.setActiveAccount(response.account);
    }
  } catch (error) {
    console.error("Erro no MSAL:", error);
  }
};

export const login = async () => {
  if (!msalInstance) return;
  const request = {
    scopes: ["Calendars.Read.Shared", "User.Read", "Directory.Read.All"],
    prompt: "select_account",
    redirectUri: REDIRECT_URI
  };
  try {
    const result = await msalInstance.loginPopup(request);
    msalInstance.setActiveAccount(result.account);
    return result.account;
  } catch (e: any) {
    if (e.message?.includes("iframe")) throw new Error("IFRAME_BLOCK");
    await msalInstance.loginRedirect(request);
  }
};

export const getActiveAccount = () => {
  if (!msalInstance) return null;
  const accounts = msalInstance.getAllAccounts();
  return accounts.length > 0 ? accounts[0] : null;
};

const getAccessToken = async (scopes = ["Calendars.Read.Shared", "User.Read"]) => {
  if (!msalInstance) return null;
  const account = getActiveAccount();
  if (!account) return null;
  const request = { scopes, account: account };
  try {
    const result = await msalInstance.acquireTokenSilent(request);
    return result.accessToken;
  } catch (error) {
    return null;
  }
};

/**
 * Busca o nome de exibição real da sala.
 */
export const getRoomDisplayName = async (email: string): Promise<string | null> => {
  const token = await getAccessToken(["User.Read", "Directory.Read.All"]);
  if (!token) return null;
  const client = Client.init({ authProvider: (done) => done(null, token) });
  try {
    // Tenta buscar no endpoint de usuários (salas de recurso são usuários no Graph)
    const res = await client.api(`/users/${email}`).select("displayName").get();
    return res.displayName;
  } catch (e) {
    console.warn("DisplayName não encontrado via API, usando fallback.");
    return null;
  }
};

export const fetchRoomMeetings = async (email: string): Promise<Meeting[]> => {
  const token = await getAccessToken(["Calendars.Read.Shared"]);
  if (!token) return [];
  const client = Client.init({ authProvider: (done) => done(null, token) });

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date();
  endOfDay.setHours(23, 59, 59, 999);

  try {
    // Para evitar 'Object not found', garantimos que estamos acessando o calendário padrão da sala explicitamente
    const response = await client.api(`/users/${email}/calendar/calendarView`)
      .query({
        startDateTime: startOfDay.toISOString(),
        endDateTime: endOfDay.toISOString()
      })
      .select("id,subject,organizer,start,end,sensitivity,showAs")
      .orderby("start/dateTime")
      .get();

    return (response.value || []).map((event: any) => ({
      id: event.id,
      subject: event.subject || "Reunião Sem Título",
      organizer: event.organizer?.emailAddress?.name || "Organizador",
      startTime: new Date(event.start.dateTime + (event.start.dateTime.endsWith('Z') ? '' : 'Z')),
      endTime: new Date(event.end.dateTime + (event.end.dateTime.endsWith('Z') ? '' : 'Z')),
      isPrivate: event.sensitivity === "private"
    }));
  } catch (error: any) {
    console.error("Erro ao buscar CalendarView:", error);
    
    // Fallback: Tenta buscar via events caso o calendário padrão tenha um ID diferente ou não esteja mapeado como 'calendar'
    try {
      const fallbackResponse = await client.api(`/users/${email}/events`)
        .filter(`start/dateTime ge '${startOfDay.toISOString()}' and start/dateTime le '${endOfDay.toISOString()}'`)
        .select("id,subject,organizer,start,end,sensitivity")
        .get();
        
      return (fallbackResponse.value || []).map((event: any) => ({
        id: event.id,
        subject: event.subject || "Reunião Sem Título",
        organizer: event.organizer?.emailAddress?.name || "Organizador",
        startTime: new Date(event.start.dateTime + (event.start.dateTime.endsWith('Z') ? '' : 'Z')),
        endTime: new Date(event.end.dateTime + (event.end.dateTime.endsWith('Z') ? '' : 'Z')),
        isPrivate: event.sensitivity === "private"
      }));
    } catch (fallbackError) {
      console.error("Fallback também falhou:", fallbackError);
      if (error.status === 403) throw new Error("INSUFFICIENT_PRIVILEGES");
      return [];
    }
  }
};
