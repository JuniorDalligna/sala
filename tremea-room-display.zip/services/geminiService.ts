
import { GoogleGenAI } from "@google/genai";
import { Meeting } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getSmartAgendaSummary = async (meetings: Meeting[], roomName: string) => {
  if (meetings.length === 0) return "Sala livre o dia todo.";

  const meetingList = meetings.map(m => 
    `- ${m.subject} às ${m.startTime.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`
  ).join('\n');

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Resuma a agenda de hoje para a ${roomName} de forma amigável e curta (máximo 2 frases). 
      Destaque se o dia está cheio ou tranquilo. 
      Agenda:\n${meetingList}`,
    });
    return response.text;
  } catch (error) {
    return "Confira a agenda abaixo para os detalhes das reuniões de hoje.";
  }
};
